<?php
   $db_host = 'localhost';
   $db_user = 'root';
   $db_pass = 'root';
   $db_name = 'my_database';
   $port = '3306';
?>
